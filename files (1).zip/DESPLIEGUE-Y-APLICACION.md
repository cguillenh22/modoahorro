# ModoAhorro — guía de despliegue y aplicación a Awin

## 1. Dominio: ModoAhorro.pe

Elegiste `.pe`, que se gestiona vía **NIC.pe** (o un registrador afiliado como PeruDomain) y **no siempre activa el mismo día** — a veces toma de horas a un par de días hábiles, a diferencia de un `.com` que activa al instante.

**Recomendación para no perder la noche:** registra en paralelo `modoahorro.com` en Namecheap o GoDaddy (~US$ 8-14/año, activación instantánea). Úsalo para levantar el sitio y empezar a generar contenido/historial *ya*, y cuando el `.pe` active, apunta ahí como dominio principal (o simplemente redirige el `.com` al `.pe` más adelante). Awin no exige un TLD específico — lo que revisa es que el sitio sea real y funcional, no la extensión del dominio.

Si prefieres esperar solo al `.pe`, no hay problema — simplemente el arranque de "esta noche" se corre a cuando NIC.pe confirme la activación.

## 2. Deploy en GitHub Pages (gratis, ~10 minutos)

1. Crea una cuenta en GitHub si no tienes una
2. Crea un repositorio nuevo, público, llamado por ejemplo `ahorro-consciente`
3. Sube todos los archivos de esta carpeta (`index.html`, `sobre-mi.html`, `style.css`, `articulos/`) a la raíz del repo
4. Ve a **Settings → Pages**, en "Source" selecciona la rama `main` y carpeta `/root`
5. En 1-2 minutos tu sitio estará vivo en `https://tu-usuario.github.io/ahorro-consciente/`
6. Para usar tu dominio propio: en Settings → Pages, agrega tu dominio en "Custom domain". En el panel de Namecheap, ve a "Advanced DNS" y agrega:
   - Un registro `CNAME` apuntando `www` → `tu-usuario.github.io`
   - Registros tipo `A` para el dominio raíz apuntando a las IPs de GitHub Pages (185.199.108.153, 185.199.109.153, 185.199.110.153, 185.199.111.153)
7. La propagación de DNS puede tardar de minutos a un par de horas — **no es necesario esperar a que el dominio propio esté activo para empezar la aplicación**, puedes usar la URL de github.io mientras tanto y luego pedirle a Awin que actualice la URL, o simplemente esperar a tener el dominio final antes de aplicar.

**Alternativa aún más rápida si el DNS te complica:** usa Netlify (arrastras la carpeta del sitio directo a netlify.com/drop) y obtienes una URL activa en segundos, sin necesidad de GitHub. Luego conectas tu dominio propio desde el panel de Netlify.

## 3. Texto para el formulario de aplicación en Awin

**Descripción del sitio/empresa (campo "Overview"):**

> ModoAhorro es un blog de finanzas personales enfocado en el público peruano. Publicamos guías prácticas sobre ahorro, uso de la CTS, manejo de deuda de tarjetas de crédito e inversión básica, con un enfoque educativo y sin promesas de rentabilidad. El sitio incluye comparativas de productos financieros (cuentas de ahorro, instrumentos de inversión) pensadas para ayudar al lector a decidir con información clara antes de contratar cualquier producto.

**Tipo de promoción a seleccionar:**
- Primario: **Content Creators & Influencers** (subcategoría: Social & Blogger)
- Secundario (si el formulario permite varios): **Editorial**

**URL a registrar:** la de tu dominio final (`modoahorro.pe` o `modoahorro.com` mientras el `.pe` activa)

## 4. Qué falta antes de aplicar

- [ ] Dominio comprado y apuntando al sitio (o al menos una URL pública activa)
- [ ] Los 6 archivos de contenido visibles y navegables desde el menú
- [ ] Página "Sobre mí" visible (Awin la revisa para validar que el sitio es real y no una cáscara vacía)
- [ ] Tarjeta lista para el fee de verificación de US$/£ 5 en el registro

## 5. Después de la aprobación

Una vez aprobada la cuenta de publisher, el perfil debe completarse al 100% (descripción, promotional spaces, URL) antes de poder postular a programas de advertisers individuales — un perfil incompleto es invisible en el directorio para los advertisers, aunque la cuenta ya esté aprobada.
